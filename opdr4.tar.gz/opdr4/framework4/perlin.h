#ifndef PERLIN_H
#define PERLIN_H

void    init_noise(void);
double  noise(double x, double y, double z);
double  snoise(double x, double y, double z);

#endif
